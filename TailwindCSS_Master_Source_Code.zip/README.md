# Tailwind CSS Master Source Code

## Chapters
1. Introduction
2. Colors
3. Typography
4. Spacing
5. Flexbox
6. Grid
7. Borders
8. Buttons
9. Cards
10. Responsive Design
11. Forms
12. Animations
13. Dark Mode
14. Customization
15. Final Project

## How to Run
Open any index.html file in your browser.

## Author
Vipin Kumar
